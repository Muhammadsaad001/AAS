import { useState } from "react";
import footer from "./footer";
import Footer2 from "./footer2";
function States(){
    const[name,setName]=useState("Competitions");
    const [about,setabout]=useState("About FIFA");
    const [women,setWomen]=useState("Women's Football");
    const [social,setsocial]=useState("Social Impact");
    const [Football,setfooter]=useState("Football Develpment");
    const[technical,setecnical]=useState("Technical");
    const[legal,setlegal]=useState("Legal and Compliance");
    const[fifa,setfifa]=useState("FIFA/Coca-cola world ranking")

    function handlechange(){
        console.log(name);
        setName(name);
    }
    return(
        <div>
            <h2 id="design">FIFA</h2>
            <h5 id="dev">EXPLORE</h5>
            <Footer2 name={name} about={about} women={women} social={social} Football={Football} technical={technical} legal={legal} fifa={fifa} />
        </div>
    )
}
export default States;