import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from "react-router-dom";
 
 import "./frontend.css";
 import Frontend from './frontend';
 import Layout from './layout';
 import Homies from './Homies';
 import Itemcard from "./itemcard";
 import Prices from './prices';
import Cards from "./cards";
import Devision from "./devision";
import Buy from "./Buy";
import Match from "./Match";
import Blue from "./blue";
import Working from "./working";
import Bottom from "./bottom";
import Bottom1 from './bottom1';
import Bottom2 from './bottom2';
import Bottom3 from './bottom3';
import Footer from './footer';
import Footer1 from './footer1';
import Footer3 from './footer3';
import Footer5 from './footer5';
import Footer6 from './footer6';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
   //<React.StrictMode>
    // <App />
   //</React.StrictMode></React.StrictMod>
   
    <div>
  <BrowserRouter>


  


   <Routes>
    
     <Route  path="/"element={<Layout/>}>
    <Route path="frontend" element={<Frontend />}/>
    <Route path ="Homies" element={<Homies/>}/>
    <Route  path="itemcard" element={<Itemcard/>}/>
    <Route  path="prices" element={<Prices/> }/> 
    <Route path="cards" element={<Cards/>}/>
    <Route path="devision" element={<Devision/>}/>
    <Route path="buy" element={<Buy/>}/>
    <Route path="match" element={<Match/>}/>
    <Route path="blue" element={<Blue/>}/>
    
    </Route>
    
    </Routes> 
   
  <Working/>
  <Bottom/>
  <Bottom1/>
  <Bottom2/>
  <Bottom3/>
  <Footer/>
  <Footer1/>
  <Footer3/>
  <Footer5/>
  <Footer6/>

 </BrowserRouter>
 </div>
 


 );
 


// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
//reportWebVitals();
