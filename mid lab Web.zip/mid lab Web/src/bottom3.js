function bottom3(){
    return(
        <div id="date">
            <p>Updated 6 Oct 2022</p>
            <h4 style={{color:"blue"}}>Check full men's ranking table</h4>
            <div id="dates">
            <p>Updated 13 Oct 2022</p>
            <h4 style={{color:"blue"}}>Check full women's ranking table</h4>
            </div>
        </div>
    );
}
export default bottom3;