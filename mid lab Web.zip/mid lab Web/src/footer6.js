function footer6(){
    return(
        <ul>
            <div id="fifu" className="table-table border" class="divv"  style={{width : "75vw"}}>
                <li id="sss" >
                <p>Term of services</p>
                </li>
                <li id="sss">
                <p>Data portection Portal</p>
                </li>
                 <li id="sss">
                 <p> Downloads</p>
                 </li>
                 <li id="sss">
                 <p> Cookie settings</p>
                 </li>
                 </div>
                 <div>
                 <h5 id="zoo">Copyright 1994-2005 FIFA.All right reserved</h5>
                 
                 </div>
                 </ul>
    );

}
export default footer6;