import { useState } from "react";
import Footer4 from "./footer4";
function Footer3 (){
const[stories,setstories]=useState("All stories and topics");
const[official,setofficial]=useState("Official documents");
const [jobs,setjobs]=useState("jobs and Careers");
const [contact,setcontact]=useState("Contact FIFA");
return(<div>

<Footer4 stories={stories} official={official} jobs={jobs} contact={contact} />
</div>);
}
export default Footer3;