 import {useState} from "react";
 function Working(){
const[menu,Setmenu]=useState([
  {id:"1",image : <img src={require('./img/messi.jpeg')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data1:"Football Unites the world",data4:"Matuidi: Football has the power to " ,date1:"create better world" },
  {id:"2",image :<img src={require('./img/ronaldo.jpg')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data2:"Football United the world",data5:"Mario Yepes: Football needs to ",date2:"provide a bridge towards our children"},
  {id:"3",image :<img src={require('./img/neymar.jpg')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data3:"Football United the world",data6:"Mario Yepes: Football needs to",date3:"provide a bridge"},
  {id:"4",image :<img src={require('./img/foot.jpeg')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data9:"Football United the world",data7:"Global stars join FIFA in launching Football Unites",date4:"the World campaign"},
  {id:"5",image :<img src={require('./img/che.png')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data9:"Football United the world",data7:"Global stars join FIFA in launching Football Unites",date4:"the World campaign"},
  {id:"6",image :<img src={require('./img/che.png')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data10:"Football United the world",data11:"Global stars join FIFA in launching Football Unites",date12:"the World campaign"},
  {id:"7",image :<img src={require('./img/che.png')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data13:"Football United the world",data14:"Global stars join FIFA in launching Football Unites",date15:"the World campaign"},
 
  {id:"9",image :<img src={require('./img/che.png')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data16:"Football United the world",data17:"Global stars join FIFA in launching Football Unites",date18:"the World campaign"},
  {id:"10",image :<img src={require('./img/che.png')} alt="noloaded " style={{height:"20vh",width:"10vw"}}/>,data10:"Football United the world",data11:"Global stars join FIFA in launching Football Unites",date12:"the World campaign"},
]
);
 function handleDelete  (studentID) {
  console.log("Deleting.." + studentID);

 const filteredData = menu.filter( (se)=> se.id != studentID );

 Setmenu(
  filteredData
 );

  console.log("Deleted...");
 }
  return (
    
          <div id="rocky">
             <div>
         <h4 id="lefty">
             Football Unites the
          </h4>
            <h4 id="lefty">
             World
           </h4>
          <p id="lefty">
          Football Unites The World is a Global
         </p>
          <p id="lefty">
             movement to inspire,unite and 
       </p>
         <p id="lefty">
           develop through football.
          </p>
          <h5 id="lefty">
            More From This topic
            </h5>
            <div id="style">
            {
              menu.map((m) =>(
                <div className="card" id="cards">
                  <div className="card-body">
                   <p id="bb">{m.image}</p>
                
                   <h5 className="card-title">{m.data1}</h5>
                   <h5 className="card-title">{m.data2}</h5>
                   <h5 className="card-title">{m.data3}</h5>
                   <p className="card-title">{m.data4}</p>
                   <p className="card-title">{m.data5}</p>
                   <p className="card-title">{m.data6}</p>
                   <p className="card-title">{m.date1}</p>
                   <p className="card-title">{m.date2}</p>
                   <p className="card-title">{m.date3}</p>
                   
                   <h5 className="card-title" class="saad">{m.data9}</h5>
                   <p className="card-title" class="saad1" >{m.data7}</p>
                   <p className="card-title" class="saad2">{m.date4}</p>
                   <h5 className="card-title" class="saad">{m.data10}</h5>
                   <p className="card-title" class="saad1" >{m.data11}</p>
                   <p className="card-title" class="saad2">{m.date12}</p>
                   <h5 className="card-title" class="saad">{m.data13}</h5>
                   <p className="card-title" class="saad1" >{m.data14}</p>
                   <p className="card-title" class="saad2">{m.date15}</p>
                   <h5 className="card-title" class="saad">{m.data16}</h5>
                   <p className="card-title" class="saad1" >{m.data17}</p>
                   <p className="card-title" class="saad2">{m.dat19}</p>
                  
                   
                    <button  id="zee"className="btn btn-danger" onClick={(se) => handleDelete(m.id)}>Delete</button>
                  </div>
                  </div>
              ))
            }
            </div>

  
  </div>
     </div>
     
       );
         }
       export default Working;
