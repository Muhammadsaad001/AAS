import { Component } from "react";

class MappingTable extends Component {
    
    state = {
        student : [
            { id: 1, name: "Ali", item:"T-shirt" ,price:"500"},
            { id: 2, name: "Ahmad", item:"pent",price:"1000"},
            { id: 3, name: "Fatima", item:"T-shirt",price:"500" },
            { id:4,   name:"Akhtar",item:"Mobile",price:"12000"},
            { id: 5,name:"Raza",item:"sofa",price:"4000"},
            { id:6,name:"abdullah",item:"trouser",price:"600"},
            { id:7,name:"saad",item:"Checkshirt",price:"1300"},
            { id:9,name:"David",item:"multifoam",price:"1900"},
            {id :10,name:"Willisiam",item:"mobilephone",price:"47000"}
        ]
     } 

handleDelete = (studentID) => {
        console.log("Deleting.." + studentID);

        const filteredData = this.state.student.filter( studentData => studentData.id != studentID );

        this.setState({
            student: filteredData
        });

        console.log("Deleted...");
    }
 
     render() { 
        return (
            <div>
                <table className="table table-bordered">
                    <tr>
                        <th>ID</th>
                      <th>Name</th>
                        <th>items</th>
                        {/* <th>image</th> */}
                         <th>price</th>
                        <th>Operations</th>
                        <th></th>
                    </tr>

                    {

                        this.state.student.map((studentRecord, key) => (
                            <tr key={studentRecord.id}>
                                <td>{studentRecord.id}</td>
                                <td>{studentRecord.name}</td>
                                <td>{studentRecord.item}</td>
                                <td>{studentRecord.price}</td>
        <button className="btn btn-danger" onClick={() => this.handleDelete(studentRecord.id)}>Delete</button>
                    </tr> 
                        
                        ))
                        
                    }
                 

                    
                  

                    </table>
                    
                </div>
            );
        }
    }
     
    export default MappingTable;