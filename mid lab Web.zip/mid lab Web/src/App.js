import React from "react";
 import Frontend from './frontend';
import Homies from "./Homies";
 import Itemcard from "./itemcard";
import Prices from "./prices";
import Cards from "./cards";
import Devision from "./devision";
import Buy from "./Buy";
import Blue from "./blue.js";
import "./frontend.css";
import Working from "./working";
import Bottom from "./bottom";
import Bottom1 from "/bottom1";
import Bottom2 from "./bottom2";
import Bottom3 from "./bottom3";
import Footer from "./footer";
import Footer1 from "./footer1";
import Footer3 from "./footer3";
import Footer5 from "./footer5";
import Footer6 from "./footer6";

function App() {
  return (
        <div class="body">
        
          <Frontend/>
          <Homies/>
          <Itemcard/>
          <Prices/>
          <Cards/>
          <Devision/>
          <Buy/>
          <Blue/>
          <Working/>
          <Bottom/>
          <Bottom1/>
          <Bottom2/>
          <Bottom3/>
          <Footer/>
          <Footer1/>
          <Footer3/>
          <Footer5/>
          <Footer6/>
          
    </div>
    
  );
 }

 export default App;
