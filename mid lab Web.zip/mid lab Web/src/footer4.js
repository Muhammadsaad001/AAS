function footer4({stories,official,jobs,contact}){
    return(<div id="sides">
        <h5>ALSO VISIT</h5>
      <p>{stories}</p>
      <p>{official}</p>
      <p>{jobs}</p>
      <p>{contact}</p>
    </div>);
}
export default footer4;