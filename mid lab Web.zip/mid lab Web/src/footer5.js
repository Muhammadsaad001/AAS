function footer5(){
    return (
         <ul>
            <div id="fify" class="divv"  style={{width : "75vw"}}>
                <li id="sss" >
                <img src={require('./img/facebook.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                </li>
                <li id="sss">
                <img src={require('./img/insta.webp')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                </li>
                 <li id="sss">
                 <img src={require('./img/twitter.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 <li id="sss">
                 <img src={require('./img/whatsapp.webp')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 <li id="sss">
                 <img src={require('./img/youtube.jpg')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 <li id="sss">
                 <img src={require('./img/tiktok.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 <li id="sss" >
                 <img src={require('./img/club.webp')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 
                 </div>
            </ul>
    );

}
export default footer5;