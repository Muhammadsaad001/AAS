import { Component } from "react";

class bottom1 extends Component {
    
    state = {
        student : [
            { id: 1, Teams:  <img src={require('./img/brazil.jpeg')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>, teem:"brazil" ,totalpoints:"500"},
            { id: 2, Teams:<img src={require('./img/belguim.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/> ,teem:"belguim",totalpoints:"1000"},
            { id: 3, Teams:<img src={require('./img/argentina.webp')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>,teem:"argentina", totalpoints:"500" },
            {  id:4, Teams:<img src={require('./img/france.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>,teem:"france",totalpoints:"12000"},
            { id: 5, Teams:<img src={require('./img/england.webp')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>,teem:"england",totalpoints:"4000"},
        ]
     } 

handleDelete = (studentID) => {
        console.log("Deleting.." + studentID);

        const filteredData = this.state.student.filter( studentData => studentData.id != studentID );

        this.setState({
            student: filteredData
        });

        console.log("Deleted...");
    }
 
     render() { 
        return (
            <div id="xsaadx">
                <table className="table table">
                    <h2>MEN</h2>
                    <tr>
                        
                        <th>RK</th>
                      <th>Team</th>
                      <div id="saadii">
                       <th >totalpoints</th>
                       </div>
                    </tr>

                    {

                        this.state.student.map((studentRecord, key) => (
                            <tr key={studentRecord.id}>
                                <td>{studentRecord.id}</td>
                                <td>{studentRecord.Teams}</td>
                                <td>{studentRecord.teem}</td>
                                <div id="value">
                                <td>{studentRecord.totalpoints}</td>
                                {/* <button className="btn btn-danger" onClick={() => this.handleDelete(studentRecord.id)}>Delete</button> */}
                               </div>
                    </tr> 
                        
                        ))
                        
                    }
                 

                    
                  

                    </table>
                    
                </div>
            );
        }
    }
     
    export default bottom1;