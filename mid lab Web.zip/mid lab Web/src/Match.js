

function match({}){
    return(
        <div>
            
               <h2>
                quantity:{}
               </h2>
            
        </div>
    );
}
export default match;