import { Link, Outlet,  } from "react-router-dom";
import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css'

const layout = () => {
  return (
    <>
    
    
    
        <nav>
          <ul>
            <div id="zz">
            
            
          
            
          FIFA <input  id="qwe" type="text" name="search" placeholder="Search.."/> 


          <button id="nn" type="button">Store</button>

          <button id="nn" type="buttton">Tickets</button>

          <button id="nn" type="button">Login</button>
            </div>
            <div class="divv" style={{width : "100vw"}}> 
          
            
           <li id="sty">
            <Link class="cxx" to="/frontend">Registration</Link>
          </li>
          <li id="sty">
            <Link class="cxx" to="/Homies" >Sign in</Link>
          </li>
          <li id="sty">
            <Link  class="cxx" to="itemcard">Item card</Link>
          </li>
          <li id="sty">
            <Link  class="cxx"to="prices">Prices</Link>
          </li> 
          <li id="sty">
           <Link class="cxx" to="/cards">cards</Link>
          </li>
          <li id="sty">
            <Link class="cxx" to="devision">devision</Link>
          </li>
          <li id="sty">
            <Link class="cxx" to="buy">Buy</Link>
          </li>
          <li id="sty">
            <Link class="cxx" to="Match">Match</Link>
          </li>
          <li id="sty">
            <Link class="cxx" to="blue">blue</Link>
          </li>
          
          
         
          </div>

        </ul>
        </nav>
        <ul>
            <div id="feu" className="table-table border" class="divv"  style={{width : "75vw"}}>
              <ul>
              <li id="sss">
               
                  <a  id="ss"href="http//www.google.com" >which football team support
                  <select>
                    <option>Privacy
                    <a href="www.google.com"></a>
                    </option>
                    <option>Terms</option>
                    </select></a>
                  
              </li>

              </ul>

                {/* <li id="sss" >
                  
                <select name="cars" id="cars">
                  
           <option value="volvo">Argentina</option>
               <option value="saab">france</option>
           <option value="mercedes">Portugal</option>
            <option value="audi">belguim</option>
</select>
                </li> */}
                <li id="sss">
                <a  id="ss"href="#">Data portection Portal</a>
                </li>
                 <li id="sss">
                 <a id="ss" href="#"> Downloads</a>
                 </li>
                 <li id="sss">
                 <a id="ss" href="#"> Cookie settings</a>
                 </li>
                 </div>
                 
                 </ul> 
                 
             
      <Outlet />
    </>
  )
};

export default layout;