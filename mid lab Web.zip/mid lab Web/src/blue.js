import { buildQueries } from "@testing-library/react";
const mystyle={
color:"yellow"

}

function color(){
    
    return(
        <div>
            <p id="color" class="ii" style={mystyle}>hellow world lets together</p>
        </div>
    );
}
export default color;