function footer(){
    return(
        <div id="fitter" className="table-table border">
            <h5 id="side">FIFA PARTNERS</h5>
        
            <ul>
            <div class="divv"  style={{width : "75vw"}}>
                <li id="sss" >
                <img src={require('./img/adidas.jpg')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                </li>
                <li id="sss">
                <img src={require('./img/cocacol.jpg')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                </li>
                 <li id="sss">
                 <img src={require('./img/airwas.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 <li id="sss">
                 <img src={require('./img/adidas.jpg')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 <li id="sss">
                 <img src={require('./img/hyundai.webp')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 <li id="sss">
                 <img src={require('./img/visa.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 <li id="sss" >
                 <img src={require('./img/qatars.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>
                 </li>
                 
                 </div>
            </ul>
            
        </div>
    );
}
export default footer;