import {useState} from "react";
function Front(){
  const [name, setName] = useState("");
  const [password,setPassword]=useState("");
  const handleSubmit = (event) => {
    
    alert("the form was not submitted");
  }
  const handlechange=(e)=>{
    const newUsername=e.currentTarget.value;
    setName(newUsername);
    console.log(e.currentTarget.value);
  }
  const handlechange2=(e)=>{
    const newPassword=e.currentTarget.value;
    setPassword(newPassword);
    console.log(e.currentTarget.value);
  }
  
   
    return (
      <div id="style">
<div id="steps">
  
  <h1 id="title">
  Ecommerece Shopping 
  
</h1>
<p id="description">
  Enter the required data in the boxes.
</p>
  
</div>
<div id="disco"/>
  
  <form onSubmit={handleSubmit} id="survey-form"/>
  <form>
    <label id="name-label">Name</label>
      <input value={name}  onChange={handlechange}type="text" id="name" name="name" class="form" required placeholder="Insert your name"/><br></br>
      <input type="submit" />
      </form>
    <label id="email-label">Email</label>
      <input type="email" id="email" name="email" class="form" required placeholder="Insert your email"/><br></br>
    <label id="number-label">Age</label>
      <input type="number" id="number" name="number" class="form" placeholder="Age" min="19" max="60" required/><br></br>
      <label id="number-label">Password</label>
      <input type="Password" value={password} onChange={handlechange2} id="number" name="number" class="form" placeholder="Password"  required/><br></br>
    <label id="carrer">Carrer</label>
    <select id="dropdown" name="role" required>
      <option disabled selected value>
        Select your Province
      </option>
      <option value="ISC">
        Punjab
      </option>
      <option value="IMA">
        Kyber Pakhtoon Khawa
      </option>
      <option value="II">
        Sindh
      </option>
      <option value="IGE">
        Balochistan
      </option>
    </select>
    <p>Genre</p>
    <label>
      <input type="radio" name="genre" value="Male"/>Male
    </label>
    <label>
      <input type="radio" name="genre" value="Female"/>Female
    </label>
    <label>
      <input type="radio" name="genre" value="Other"/>I prefer not to answer
    </label>
    
    <p>Any comments or suggestions?</p>
      <textarea
        id="comments"
        name="comment"
        placeholder="Enter your comment here..."
      ></textarea>
    
    <input type="submit" id="submit" name="submit" value="Submit"/>
  {name}
  {password}
</div>



      
    );
}
export default Front;