function footer2 ({name,about,women,social,Football,technical,legal,fifa}){
    return(<div id="sidee">
      <p>{name}</p>
      <p>{about}</p>
      <p>{women}</p>
      <p>{social}</p>
      <p>{Football}</p>
      <p>{technical}</p>
      <p>{legal}</p>
       <p>{fifa}</p>
    </div>);
}
export default footer2;