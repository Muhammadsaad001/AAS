import { Component } from "react";

class bottom2 extends Component {
    
    state = {
        student : [
            { id: 1, Teams:  <img src={require('./img/america.jpeg')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>, teem:"america" ,totalpoints:"500"},
            { id: 2, Teams:<img src={require('./img/sweden.webp')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/> ,teem:"sweden",totalpoints:"1000"},
            { id: 3, Teams:<img src={require('./img/france.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>,teem:"france", totalpoints:"500" },
            {  id:4, Teams:<img src={require('./img/belguim.png')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>,teem:"belguim",totalpoints:"12000"},
            { id: 5, Teams:<img src={require('./img/england.webp')} alt="noloaded " style={{height:"5vh",width:"5vw"}}/>,teem:"england",totalpoints:"4000"},
        ]
     } 

handleDelete = (studentID) => {
        console.log("Deleting.." + studentID);

        const filteredData = this.state.student.filter( studentData => studentData.id != studentID );

        this.setState({
            student: filteredData
        });

        console.log("Deleted...");
    }
 
     render() { 
        return (
            <div id="newport">
                <table className="table table">
                    <h2 class="women">WOMEN</h2>
                    
                    <tr>
                        
                        <th>RK</th>
                      <th>Team</th>
                      <div id="th">
                       <th class="th">totalpoints</th>
                       </div>
                    </tr>
                    
                    {

                        this.state.student.map((studentRecord, key) => (
                            <tr key={studentRecord.id}>
                                <td>{studentRecord.id}</td>
                                <td>{studentRecord.Teams}</td>
                                <td>{studentRecord.teem}</td>
                                <div id="td">
                                <td>{studentRecord.totalpoints}</td>
                                </div>
                    </tr> 
                        
                        ))
                        
                    }
                 

                    
                  

                    </table>
                    
                </div>
            );
        }
    }
     
    export default bottom2;