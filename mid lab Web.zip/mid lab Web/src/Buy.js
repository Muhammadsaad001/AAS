import Match from "./Match";
import {useState} from "react";
function Buy(){
   const [price,setPrice]=useState(1265000);
    function brokerprice(){
        setPrice(price+1);
    }
    
    return(
        <div>
            {price}
            <button onClick={brokerprice} style={{width:50,height:20}} className="btn-btn-danger"></button>
           <Match quantity={price}/>
        </div>
    );
}
export default Buy;