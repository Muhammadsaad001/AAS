function bottom(){
    return (
        <div id="pipo">
         <img id="micky"  src={require('./img/cocacol.jpg') }/>
         <h2 id="h1">|</h2>
          <h1 id="h2">FIFA</h1>
          <h1>WORLD RANKING</h1>
          <p>The official world ranking of the</p>
          <p>international mens and womens</p>
          <p>teams.</p>
          <h2 id="mystyle">FIFA/Coca-Cola World ranking</h2>
          
        </div>
    );
}
export default bottom;