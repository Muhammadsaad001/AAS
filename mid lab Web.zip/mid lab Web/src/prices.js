import { render } from "@testing-library/react";
import { Component } from "react";
import { useState } from "react";

import React from "react";

 function Total(){
    
        const[count,setCount]=useState(1);
        const[Total,setTotal]=useState(500);
        const[pentTotal,setpentTotal]=useState(1000);
        const[mobile,setmobile]=useState(12000);
        const[multifoam,setmultifoam]=useState(1900);
        
        
    return(
        <div>
            <div>
            <h1>T-shirt Price</h1>
         <p>The quantity of items are {count}</p>
      <button onClick={() => setCount(count + 1)}>increase items</button>
 <p>The total price are {Total}</p>
       <button onClick={() => setTotal(count *500)}>prices increase</button>
       </div>
       
       <div>
        <h1>Pent Price</h1>
        <p>The quantity of items are {count}</p>
        <p>The  total price are {pentTotal}</p>
        <button onClick={()=>setpentTotal(count*1000)}>price increases</button>
        
       </div>
       <div>
       <h1>Mobile Price</h1>
        <p>The quantity of items are {count}</p>
        <p>The  total price are {mobile}</p>
        <button onClick={()=>setmobile(count*12000)}>price increases</button>
       </div>
       <div>
        <h1>Multifoam price</h1>
        <p>The quantity of items are {count}</p>
        <p>The total price are{multifoam}</p>
        <button onClick={()=>setmultifoam(count*1900)}>Price increase</button>
       </div>
        </div>
    );
}

export default Total;